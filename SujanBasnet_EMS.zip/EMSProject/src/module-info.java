/**
 * 
 */
/**
 * 
 */
module EMSProject {
	requires java.desktop;
}