package EMS;

import java.util.Scanner;

public class TextPerformanceManager {

    public static void managePerformance(Scanner sc, EmployeeManager manager) {
        int id = InputUtils.readInt(sc, "Enter Employee ID: ");
        Employee emp = manager.findById(id);

        if (emp != null) {
            boolean back = false;
            while (!back) {
                System.out.println("\n--- Manage Performance & Salary ---");
                System.out.println("1. View Performance and Salary");
                System.out.println("2. Issue Warning Letter");
                System.out.println("3. Issue Appreciation Letter");
                System.out.println("4. Apply Bonus");
                System.out.println("5. Apply Fine");
                System.out.println("6. Back to Main Menu");

                int perfChoice = InputUtils.readInt(sc, "Choose an option: ");

                switch (perfChoice) {
                    case 1 -> emp.viewPerformanceAndSalary();
                    case 2 -> emp.issueWarningLetter();
                    case 3 -> emp.issueAppreciationLetter();
                    case 4 -> emp.applyBonus(InputUtils.readDouble(sc, "Enter bonus amount: "));
                    case 5 -> emp.applyFine(InputUtils.readDouble(sc, "Enter fine amount: "));
                    case 6 -> back = true;
                    default -> System.out.println("Invalid choice.");
                }
            }
        } else {
            System.out.println("Employee not found.");
        }
    }
}
