// TextFileOperations.java
package EMS;

import java.util.Scanner;

public class TextFileOperations {

    public static String saveToFile(Scanner sc, EmployeeManager manager) {
        String filename = sc.nextLine().trim();
        if (!filename.isEmpty()) {
            FileHandler.saveToFile(filename, manager.employees);
        } else {
            System.out.println("Invalid filename. Please try again.");
        }
        return filename;
    }
}