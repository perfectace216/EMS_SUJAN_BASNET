package EMS;

import javax.swing.*;
import java.awt.*;

public class EMSGui extends JFrame {

    private final EmployeeManager manager;
    private final String filename;
    private EmployeeTablePanel tablePanel;

    public EMSGui(EmployeeManager manager, String filename) {
        this.manager = manager;
        this.filename = filename;

        setTitle("Employee Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 600);
        setLocationRelativeTo(null);

        initComponents();
    }

    private void initComponents() {
        tablePanel = new EmployeeTablePanel(manager);
        EmployeeButtonPanel buttonPanel = new EmployeeButtonPanel(manager, filename, tablePanel);

        add(buttonPanel, BorderLayout.SOUTH);
        add(tablePanel, BorderLayout.CENTER);
    }
}
