package EMS;

public class Intern extends Employee {
    public Intern(int id, String name, String department, int performanceRating, double baseSalary) {
        super(id, name, department, performanceRating, baseSalary);
    }

    @Override
    public double calculateSalary() {
        return baseSalary;
    }
}
