package EMS;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class EmployeeSearchDialog extends JDialog {
	private static final long serialVersionUID = 1L;  // 🔧 Fix for the warning
    public EmployeeSearchDialog(JFrame parent, List<Employee> results) {
        super(parent, "Search Results", true);
        setSize(700, 300);
        setLocationRelativeTo(parent);
        JTable table = new JTable(new EmployeeTableModel(results));
        add(new JScrollPane(table));
        setVisible(true);
    }
}
