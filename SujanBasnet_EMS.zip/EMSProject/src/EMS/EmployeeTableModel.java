package EMS;

import javax.swing.table.AbstractTableModel;
import java.util.List;

public class EmployeeTableModel extends AbstractTableModel {

    private static final long serialVersionUID = 1L;

    private final String[] columnNames = {"ID", "Name", "Department", "Type", "Salary", "Performance"};
    private final EmployeeManager manager;
    private final List<Employee> staticList;

    // Constructor for live data from EmployeeManager
    public EmployeeTableModel(EmployeeManager manager) {
        this.manager = manager;
        this.staticList = null;
    }

    // Constructor for static data (used in search)
    public EmployeeTableModel(List<Employee> list) {
        this.staticList = list;
        this.manager = null;
    }

    @Override
    public int getRowCount() {
        return staticList != null ? staticList.size() : manager.employees.size();
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public String getColumnName(int col) {
        return columnNames[col];
    }

    @Override
    public Object getValueAt(int row, int col) {
        Employee emp = (staticList != null ? staticList : manager.employees).get(row);

        return switch (col) {
            case 0 -> emp.getId();
            case 1 -> emp.getName();
            case 2 -> emp.getDepartment();
            case 3 -> emp.getClass().getSimpleName();
            case 4 -> String.format("%.2f", emp.calculateSalary());
            case 5 -> emp.getPerformanceRating();
            default -> null;
        };
    }

    @Override
    public boolean isCellEditable(int row, int col) {
        return false;
    }
}
