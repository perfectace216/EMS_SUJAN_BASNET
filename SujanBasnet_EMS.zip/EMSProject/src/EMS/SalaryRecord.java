package EMS;

import java.util.*;

public class SalaryRecord {
    public List<Double> bonuses = new ArrayList<>();
    public List<Double> fines = new ArrayList<>();

    public void addBonus(double bonus) {
        bonuses.add(bonus);
    }

    public void addFine(double fine) {
        fines.add(fine);
    }

    public double calculateAdjustments() {
        double totalBonus = bonuses.stream().mapToDouble(Double::doubleValue).sum();
        double totalFine = fines.stream().mapToDouble(Double::doubleValue).sum();
        return totalBonus - totalFine;
    }
}
