package EMS;

public abstract class Employee {
    protected int id;
    protected String name;
    protected String department;
    protected int performanceRating;
    protected double baseSalary;

    // Updated constructor based on provided fields
    public Employee(int id, String name, String department, int performanceRating, double baseSalary) {
        this.id = id;
        this.name = name;
        this.department = department;
        this.performanceRating = performanceRating;
        this.baseSalary = baseSalary;
    }

    // Abstract method to calculate salary, to be implemented by subclasses
    public abstract double calculateSalary();

    // Get employee details in CSV format (suitable for writing to file)
    public String getDetails() {
        return id + "," + name + "," + department + "," + getClass().getSimpleName() + "," + baseSalary + "," + performanceRating;
    }

    // Getters and setters for the properties
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public int getPerformanceRating() {
        return performanceRating;
    }

    public void setPerformanceRating(int performanceRating) {
        this.performanceRating = performanceRating;
    }

    public double getBaseSalary() {
        return baseSalary;
    }

    public void setBaseSalary(double baseSalary) {
        this.baseSalary = baseSalary;
    }

    // Method to update performance rating
    public void updatePerformance(int newRating) {
        this.performanceRating = newRating;
    }
    
    
    public void applyBonus(double bonusAmount) {
        this.baseSalary += bonusAmount;
        System.out.println("Bonus of $" + bonusAmount + " applied.");
    }

    public void applyFine(double fineAmount) {
        this.baseSalary -= fineAmount;
        System.out.println("Fine of $" + fineAmount + " applied.");
    }

    public void issueAppreciationLetter() {
        System.out.println("Appreciation Letter: Great job, " + name + "!");
    }

    public void issueWarningLetter() {
        System.out.println("Warning Letter: Please improve your performance, " + name + ".");
    }

    public void viewPerformanceAndSalary() {
        System.out.println("Employee ID: " + id);
        System.out.println("Name: " + name);
        System.out.println("Department: " + department);
        System.out.println("Performance Rating: " + performanceRating);
        System.out.println("Base Salary: $" + baseSalary);
    }

}
