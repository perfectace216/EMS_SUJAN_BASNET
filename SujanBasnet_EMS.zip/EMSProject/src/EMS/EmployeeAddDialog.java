package EMS;

import javax.swing.*;
import java.awt.*;

public class EmployeeAddDialog extends JDialog {

    public EmployeeAddDialog(JFrame parent, EmployeeManager manager, String filename, EmployeeTablePanel tablePanel) {
        super(parent, "Add New Employee", true);
        setSize(420, 320);
        setLocationRelativeTo(parent);
        setResizable(false);

        // Main panel with vertical layout
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 10, 20)); // 🧩 Reduced padding

        // Fields
        JTextField idField = new JTextField(15);
        JTextField nameField = new JTextField(15);
        JTextField deptField = new JTextField(15);
        JComboBox<String> typeBox = new JComboBox<>(new String[]{"Regular", "Manager", "Intern"});
        JTextField salaryField = new JTextField(15);
        JTextField ratingField = new JTextField(15);

        mainPanel.add(createFormRow("Employee ID:", idField));
        mainPanel.add(createFormRow("Name:", nameField));
        mainPanel.add(createFormRow("Department:", deptField));
        mainPanel.add(createFormRow("Type:", typeBox));
        mainPanel.add(createFormRow("Base Salary:", salaryField));
        mainPanel.add(createFormRow("Performance Rating:", ratingField));

        // Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 5));
        JButton btnAdd = new JButton("Add");
        JButton btnCancel = new JButton("Cancel");
        buttonPanel.add(btnCancel);
        buttonPanel.add(btnAdd);

        mainPanel.add(Box.createVerticalStrut(10));  // slight spacing before buttons
        mainPanel.add(buttonPanel);

        add(mainPanel);

        // Action Handlers
        btnAdd.addActionListener(e -> {
            try {
                int id = Integer.parseInt(idField.getText().trim());
                String name = nameField.getText().trim();
                String dept = deptField.getText().trim();
                String type = (String) typeBox.getSelectedItem();
                double salary = Double.parseDouble(salaryField.getText().trim());
                int rating = Integer.parseInt(ratingField.getText().trim());

                if (manager.findById(id) != null) {
                    JOptionPane.showMessageDialog(this, "Employee ID already exists.");
                    return;
                }

                Employee emp = switch (type.toLowerCase()) {
                    case "regular" -> new RegularEmployee(id, name, dept, rating, salary);
                    case "manager" -> new Manager(id, name, dept, rating, salary);
                    case "intern" -> new Intern(id, name, dept, rating, salary);
                    default -> null;
                };

                if (emp != null) {
                    manager.addEmployee(emp);
                    FileHandler.appendToFile(filename, emp);
                    tablePanel.refreshTable();
                    dispose();
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Please enter valid values.");
            }
        });

        btnCancel.addActionListener(e -> dispose());

        setVisible(true);
    }

    // 🧩 Helper to create neatly aligned label + field row
    private JPanel createFormRow(String labelText, JComponent field) {
        JPanel row = new JPanel(new BorderLayout(5, 5));
        JLabel label = new JLabel(labelText);
        label.setPreferredSize(new Dimension(140, 25));  // Align labels
        row.setBorder(BorderFactory.createEmptyBorder(3, 0, 3, 0));
        row.add(label, BorderLayout.WEST);
        row.add(field, BorderLayout.CENTER);
        return row;
    }
}
