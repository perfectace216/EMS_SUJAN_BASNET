package EMS;

public class Snippet {
	public static void main(String[] args) {
		employee_data
	}
}

