package EMS;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.awt.event.ActionListener;

public class EmployeeButtonPanel extends JPanel {

    private final JTextField searchField = new JTextField(15);

    public EmployeeButtonPanel(EmployeeManager manager, String filename, EmployeeTablePanel tablePanel) {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        // First row: action buttons
        JPanel actionRow = new JPanel(new FlowLayout(FlowLayout.CENTER));
        actionRow.add(createButton("Add Employee", e -> new EmployeeAddDialog(null, manager, filename, tablePanel)));

        actionRow.add(createButton("Delete Selected", e -> {
            Employee emp = tablePanel.getSelectedEmployee();
            if (emp != null) {
                int confirm = JOptionPane.showConfirmDialog(this, "Delete employee: " + emp.getName() + "?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    manager.deleteEmployee(emp.getId());
                    FileHandler.saveToFile(filename, manager.employees);
                    tablePanel.refreshTable();
                }
            } else {
                JOptionPane.showMessageDialog(this, "No employee selected.");
            }
        }));

        actionRow.add(createButton("Refresh", e -> tablePanel.refreshTable()));

        actionRow.add(createButton("Edit Selected", e -> {
            Employee selected = tablePanel.getSelectedEmployee();
            if (selected != null) {
                SwingUtilities.invokeLater(() -> {
                    JDialog dialog = new EmployeeEditDialog(
                        SwingUtilities.getWindowAncestor(this) instanceof JFrame
                            ? (JFrame) SwingUtilities.getWindowAncestor(this)
                            : new JFrame(),
                        selected,
                        filename,
                        tablePanel
                    );
                    dialog.setVisible(true);
                });
            } else {
                JOptionPane.showMessageDialog(this, "Please select an employee to edit.");
            }
        }));

        // Second row: search bar
        JPanel searchRow = new JPanel(new FlowLayout(FlowLayout.CENTER));
        searchRow.add(new JLabel("Name:"));
        searchRow.add(searchField);
        searchRow.add(createButton("Search", e -> {
            String name = searchField.getText().trim();
            if (name.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Enter a name.");
                return;
            }

            List<Employee> results = manager.employees.stream()
                    .filter(emp -> emp.getName().equalsIgnoreCase(name))
                    .toList();

            if (results.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No employee found.");
            } else {
                new EmployeeSearchDialog(null, results);
            }
        }));

        // Add both rows to main panel
        add(actionRow);
        add(searchRow);
    }

    private JButton createButton(String text, ActionListener action) {
        JButton btn = new JButton(text);
        btn.addActionListener(action);
        return btn;
    }
}
