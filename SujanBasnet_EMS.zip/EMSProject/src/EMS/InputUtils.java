package EMS;

import java.util.InputMismatchException;
import java.util.Scanner;

public class InputUtils {

    public static int readInt(Scanner sc, String prompt) {
        int num = -1;
        while (true) {
            try {
                System.out.print(prompt);
                num = sc.nextInt();
                sc.nextLine(); // consume newline
                break;
            } catch (InputMismatchException e) {
                System.out.println("Invalid input! Please enter a number.");
                sc.nextLine(); // clear invalid input
            }
        }
        return num;
    }

    public static double readDouble(Scanner sc, String prompt) {
        double num = -1;
        while (true) {
            try {
                System.out.print(prompt);
                num = sc.nextDouble();
                sc.nextLine(); // consume newline
                break;
            } catch (InputMismatchException e) {
                System.out.println("Invalid input! Please enter a valid number.");
                sc.nextLine(); // clear invalid input
            }
        }
        return num;
    }
}
